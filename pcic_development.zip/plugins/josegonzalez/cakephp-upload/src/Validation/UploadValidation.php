<?php

namespace Josegonzalez\Upload\Validation;

use Josegonzalez\Upload\Validation\Traits\UploadValidationTrait;

class UploadValidation
{
    use UploadValidationTrait;
}
