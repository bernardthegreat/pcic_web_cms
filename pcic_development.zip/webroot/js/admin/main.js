
ClassicEditor
.create( document.querySelector( '#editor' ), {
   
} )
.then( editor => {
    window.editor = editor;
} )
.catch( err => {
    console.error( err.stack );
} );


