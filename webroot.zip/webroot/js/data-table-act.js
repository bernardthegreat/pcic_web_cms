(function ($) {
 "use strict";
	
	$(document).ready(function() {
		 $('#data-table-basic').DataTable();
	});

	$(document).ready(function() {
		 $('#data-table').DataTable();
	});
 
})(jQuery); 